package com.odak.app.model

data class FocusTask(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val firstAction: String = "",
    val estimateMinutes: Int = 15,
    val energy: String = "Orta",
    val done: Boolean = false
)

enum class Capacity(val label: String, val emoji: String) {
    VERY_LOW("Çok düşük", "😣"),
    LOW("Düşük", "😕"),
    OK("Orta", "😐"),
    GOOD("İyi", "🙂"),
    HIGH("Yüksek", "⚡")
}

enum class RoutineIntensity(val label: String) {
    NORMAL("Normal"),
    SHORT("Kısa"),
    MINIMUM("Minimum")
}

data class RoutineTemplate(
    val id: String,
    val title: String,
    val emoji: String,
    val subtitle: String,
    val normal: List<String>,
    val short: List<String>,
    val minimum: List<String>
) {
    fun steps(intensity: RoutineIntensity): List<String> = when (intensity) {
        RoutineIntensity.NORMAL -> normal
        RoutineIntensity.SHORT -> short
        RoutineIntensity.MINIMUM -> minimum
    }
}

data class BrainItem(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val bucket: String = "Gelen Kutusu",
    val createdAt: Long = System.currentTimeMillis()
)

data class TransitionPreset(
    val id: String,
    val title: String,
    val emoji: String,
    val subtitle: String,
    val steps: List<String>
)

data class ChatMessage(
    val role: String,
    val text: String
)
