package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.odak.app.model.RoutineIntensity
import com.odak.app.model.RoutineTemplate
import com.odak.app.ui.AppState
import com.odak.app.ui.components.PageHeader
import com.odak.app.ui.components.WarmCard
import com.odak.app.ui.routines

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinesScreen(appState: AppState) {
    var active by remember { mutableStateOf<RoutineTemplate?>(null) }
    var intensity by rememberSaveable { mutableStateOf(RoutineIntensity.NORMAL) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PageHeader(
                "Rutinler",
                "Karar vermeyi azalt.",
                "Normal gün, kısa gün ve minimum gün aynı sistemin farklı yoğunlukları."
            )
        }

        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                RoutineIntensity.entries.forEachIndexed { index, item ->
                    SegmentedButton(
                        selected = intensity == item,
                        onClick = { intensity = item },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = RoutineIntensity.entries.size
                        )
                    ) { Text(item.label) }
                }
            }
        }

        item {
            LinearProgressIndicator(
                progress = { appState.completedRoutineCountToday() / routines.size.toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Bugün ${appState.completedRoutineCountToday()} / ${routines.size} rutin tamamlandı",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(routines.size) { i ->
            val r = routines[i]
            val done = appState.routineDone(r.id)
            WarmCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${r.emoji} ${r.title}", style = MaterialTheme.typography.titleLarge)
                        Text(
                            r.subtitle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (done) {
                        Icon(
                            Icons.Rounded.CheckCircle,
                            contentDescription = "Tamamlandı",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text("${r.steps(intensity).size} küçük adım")
                Button(
                    onClick = { active = r },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (done) "Yeniden çalıştır" else "Rutini başlat")
                }
            }
        }
    }

    active?.let { routine ->
        RoutineRunnerDialog(
            routine = routine,
            intensity = intensity,
            onDismiss = { active = null },
            onComplete = {
                appState.setRoutineDone(routine.id, true)
                active = null
            }
        )
    }
}

@Composable
private fun RoutineRunnerDialog(
    routine: RoutineTemplate,
    intensity: RoutineIntensity,
    onDismiss: () -> Unit,
    onComplete: () -> Unit
) {
    val steps = routine.steps(intensity)
    var index by remember(routine.id, intensity) { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${routine.emoji} ${routine.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LinearProgressIndicator(
                    progress = { (index + 1f) / steps.size },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("${index + 1} / ${steps.size}", style = MaterialTheme.typography.labelLarge)
                Text(steps[index], style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Sadece bu adım. Sonrakini şimdi düşünmene gerek yok.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (index == steps.lastIndex) onComplete() else index++
            }) {
                Text(if (index == steps.lastIndex) "Rutini kapat" else "Yaptım")
            }
        },
        dismissButton = {
            TextButton(onClick = {
                if (index == steps.lastIndex) onComplete() else index++
            }) { Text("Atla") }
        }
    )
}
