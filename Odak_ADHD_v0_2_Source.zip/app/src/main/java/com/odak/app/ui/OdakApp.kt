package com.odak.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.odak.app.ui.screens.*

enum class MainTab {
    TODAY, ROUTINES, BRAIN, FOCUS, ME
}

@Composable
fun OdakApp() {
    val context = LocalContext.current.applicationContext
    val appState = remember { AppState(context) }
    var tab by rememberSaveable { mutableStateOf(MainTab.TODAY) }
    var rescueOpen by rememberSaveable { mutableStateOf(false) }
    var cbtOpen by rememberSaveable { mutableStateOf(false) }

    if (cbtOpen) {
        AiCbtScreen(
            appState = appState,
            onBack = { cbtOpen = false }
        )
        return
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == MainTab.TODAY,
                    onClick = { tab = MainTab.TODAY },
                    icon = { Icon(Icons.Rounded.Home, null) },
                    label = { Text("Bugün") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.ROUTINES,
                    onClick = { tab = MainTab.ROUTINES },
                    icon = { Icon(Icons.Rounded.Replay, null) },
                    label = { Text("Rutin") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.BRAIN,
                    onClick = { tab = MainTab.BRAIN },
                    icon = { Icon(Icons.Rounded.Inbox, null) },
                    label = { Text("Beyin") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.FOCUS,
                    onClick = { tab = MainTab.FOCUS },
                    icon = { Icon(Icons.Rounded.Timer, null) },
                    label = { Text("Odak") }
                )
                NavigationBarItem(
                    selected = tab == MainTab.ME,
                    onClick = { tab = MainTab.ME },
                    icon = { Icon(Icons.Rounded.Person, null) },
                    label = { Text("Ben") }
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { rescueOpen = true },
                icon = { Icon(Icons.Rounded.Sos, null) },
                text = { Text("Kitlendim") }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when (tab) {
                MainTab.TODAY -> TodayScreen(
                    appState = appState,
                    onStartFocus = { tab = MainTab.FOCUS },
                    onOpenBrain = { tab = MainTab.BRAIN },
                    onOpenCbt = { cbtOpen = true }
                )
                MainTab.ROUTINES -> RoutinesScreen(appState)
                MainTab.BRAIN -> BrainScreen(appState)
                MainTab.FOCUS -> FocusScreen(appState)
                MainTab.ME -> MeScreen(
                    appState = appState,
                    onOpenCbt = { cbtOpen = true }
                )
            }
        }
    }

    if (rescueOpen) {
        RescueDialog(
            onDismiss = { rescueOpen = false },
            onStartFive = {
                rescueOpen = false
                tab = MainTab.FOCUS
            },
            onOpenCbt = {
                rescueOpen = false
                cbtOpen = true
            },
            onOpenBrain = {
                rescueOpen = false
                tab = MainTab.BRAIN
            }
        )
    }
}
