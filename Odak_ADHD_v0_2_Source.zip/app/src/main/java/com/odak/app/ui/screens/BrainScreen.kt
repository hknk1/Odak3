package com.odak.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.odak.app.data.ReminderScheduler
import com.odak.app.model.BrainItem
import com.odak.app.model.TransitionPreset
import com.odak.app.ui.AppState
import com.odak.app.ui.components.PageHeader
import com.odak.app.ui.components.SectionTitle
import com.odak.app.ui.components.WarmCard
import com.odak.app.ui.transitions
import com.odak.app.ui.theme.Sky
import com.odak.app.ui.theme.Sun

@Composable
fun BrainScreen(appState: AppState) {
    val context = LocalContext.current
    var dumpOpen by remember { mutableStateOf(false) }
    var reminderFor by remember { mutableStateOf<BrainItem?>(null) }
    var transition by remember { mutableStateOf<TransitionPreset?>(null) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PageHeader(
                "Dış Beyin",
                "Aklında tutmak zorunda değilsin.",
                "Düşünceyi dışarı çıkar, yerine koy ve gerekirse zamanı gelince geri çağır."
            )
        }

        item {
            Button(
                onClick = { dumpOpen = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🧠 Brain Dump")
            }
        }

        item {
            WarmCard {
                SectionTitle("Gelen kutusu", "Önce boşalt, sonra karar ver.")
                val inbox = appState.brainItems.filter { it.bucket == "Gelen Kutusu" }
                if (inbox.isEmpty()) {
                    Text(
                        "Şu an gelen kutusu boş.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    inbox.forEach { item ->
                        BrainItemRow(
                            item = item,
                            onMove = { appState.moveBrainItem(item.id, it) },
                            onRemind = { reminderFor = item }
                        )
                    }
                }
            }
        }

        item {
            WarmCard(tint = Sun) {
                SectionTitle("Sonra", "Şimdi yapmak zorunda olmadıkların.")
                val later = appState.brainItems.filter { it.bucket == "Sonra" }
                if (later.isEmpty()) {
                    Text("Henüz öğe yok.")
                } else {
                    later.take(8).forEach { item ->
                        Text("• ${item.text}")
                    }
                }
            }
        }

        item {
            WarmCard(tint = Sky) {
                SectionTitle(
                    "Geçiş Asistanı",
                    "Başlamak kadar bir işten diğerine geçmek de desteklenebilir."
                )
                transitions.forEach { preset ->
                    OutlinedButton(
                        onClick = { transition = preset },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("${preset.emoji} ${preset.title}")
                    }
                }
            }
        }
    }

    if (dumpOpen) {
        BrainDumpDialog(
            onDismiss = { dumpOpen = false },
            onSave = {
                appState.addBrainItem(it)
                dumpOpen = false
            }
        )
    }

    reminderFor?.let { item ->
        ReminderDialog(
            text = item.text,
            onDismiss = { reminderFor = null },
            onSchedule = { minutes ->
                if (
                    Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                ReminderScheduler.schedule(context, item.text, minutes)
                reminderFor = null
            }
        )
    }

    transition?.let { preset ->
        TransitionRunnerDialog(
            preset = preset,
            onDismiss = { transition = null }
        )
    }
}

@Composable
private fun BrainItemRow(
    item: BrainItem,
    onMove: (String) -> Unit,
    onRemind: () -> Unit
) {
    Card {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(item.text, style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = { onMove("Bugün") }, label = { Text("Bugün") })
                AssistChip(onClick = { onMove("Sonra") }, label = { Text("Sonra") })
                AssistChip(onClick = onRemind, label = { Text("Hatırlat") })
            }
            TextButton(onClick = { onMove("Sil") }) {
                Text("Bırak / sil")
            }
        }
    }
}

@Composable
private fun BrainDumpDialog(
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🧠 Brain Dump") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Düzenleme yok. Önce zihninden çıkar.")
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    minLines = 5,
                    label = { Text("Aklındaki şey") }
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(text) }, enabled = text.isNotBlank()) {
                Text("Gelen kutusuna bırak")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Kapat") } }
    )
}

@Composable
private fun ReminderDialog(
    text: String,
    onDismiss: () -> Unit,
    onSchedule: (Long) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Hatırlatıcı") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text)
                Text(
                    "Kesin saat yerine hızlı hatırlatmalar kullanıyoruz; daha gelişmiş takvim entegrasyonu sonraki sürümde."
                )
                listOf(
                    "15 dakika" to 15L,
                    "1 saat" to 60L,
                    "3 saat" to 180L,
                    "Yarın gibi düşün → 24 saat" to 1440L
                ).forEach { (label, minutes) ->
                    OutlinedButton(
                        onClick = { onSchedule(minutes) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(label) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Kapat") } }
    )
}

@Composable
private fun TransitionRunnerDialog(
    preset: TransitionPreset,
    onDismiss: () -> Unit
) {
    var index by remember(preset.id) { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${preset.emoji} ${preset.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    preset.subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LinearProgressIndicator(
                    progress = { (index + 1f) / preset.steps.size },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("${index + 1} / ${preset.steps.size}")
                Text(
                    preset.steps[index],
                    style = MaterialTheme.typography.headlineSmall
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (index == preset.steps.lastIndex) onDismiss() else index++
            }) {
                Text(if (index == preset.steps.lastIndex) "Geçiş tamam" else "Yaptım")
            }
        },
        dismissButton = {
            TextButton(onClick = {
                if (index == preset.steps.lastIndex) onDismiss() else index++
            }) { Text("Atla") }
        }
    )
}
