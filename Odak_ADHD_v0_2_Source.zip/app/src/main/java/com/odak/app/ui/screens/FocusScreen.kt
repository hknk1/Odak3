package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.odak.app.ui.AppState
import com.odak.app.ui.components.PageHeader
import com.odak.app.ui.components.WarmCard
import com.odak.app.ui.theme.Lavender
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(appState: AppState) {
    var selectedMinutes by rememberSaveable { mutableIntStateOf(15) }
    var secondsLeft by rememberSaveable { mutableIntStateOf(selectedMinutes * 60) }
    var running by rememberSaveable { mutableStateOf(false) }
    var recorded by rememberSaveable { mutableStateOf(false) }
    var distractionOpen by remember { mutableStateOf(false) }
    var bodyGoal by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(running, secondsLeft) {
        if (running && secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        } else if (secondsLeft <= 0 && !recorded) {
            running = false
            recorded = true
            appState.recordFocus(selectedMinutes)
        }
    }

    fun setMinutes(m: Int) {
        selectedMinutes = m
        secondsLeft = m * 60
        running = false
        recorded = false
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PageHeader(
                "Odak",
                "Şu an sadece bu.",
                "Zamanı görünür yap, dikkatin kaçarsa park et ve geri dön."
            )
        }

        item {
            WarmCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 15, 25, 45).forEach { m ->
                        FilterChip(
                            selected = selectedMinutes == m,
                            onClick = { setMinutes(m) },
                            label = { Text("$m dk") }
                        )
                    }
                }

                val mm = secondsLeft / 60
                val ss = secondsLeft % 60
                Text(
                    "%02d:%02d".format(mm, ss),
                    style = MaterialTheme.typography.displayLarge,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                LinearProgressIndicator(
                    progress = {
                        val total = (selectedMinutes * 60).coerceAtLeast(1)
                        1f - secondsLeft.toFloat() / total.toFloat()
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                if (secondsLeft == 0) {
                    Text(
                        "Tamamlandı 🌿. Bitirmekten çok geri dönebilmek önemli.",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Button(
                        onClick = { setMinutes(selectedMinutes) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Bir tur daha") }
                } else {
                    Button(
                        onClick = { running = !running },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (running) "Duraklat" else "Başlat")
                    }
                }

                Text(
                    "Bitirmek zorunda değilsin. Bu süre boyunca sadece görevin yanında kal.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            WarmCard(tint = Lavender) {
                Text("👥 Body Double", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Tek hedefini görünür tut. Bu bir tedavi iddiası değil; bazı kişiler için eşlik ve hesap verebilirlik aracı.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = bodyGoal,
                    onValueChange = { bodyGoal = it },
                    label = { Text("Bu oturumda tek hedefim…") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (bodyGoal.isNotBlank()) {
                    Text(
                        "Buradayız. Şimdilik sadece: $bodyGoal",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        item {
            WarmCard {
                Text("Dikkat park alanı", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Aklına gelen şeyi şimdi yapmak yerine dışarı bırak.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = { distractionOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Aklıma bir şey geldi") }
            }
        }
    }

    if (distractionOpen) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { distractionOpen = false },
            title = { Text("Sonra bakarım") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Aklına ne geldi?") }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        appState.addBrainItem(text, "Sonra")
                        distractionOpen = false
                    },
                    enabled = text.isNotBlank()
                ) { Text("Bırak ve geri dön") }
            },
            dismissButton = {
                TextButton(onClick = { distractionOpen = false }) { Text("Kapat") }
            }
        )
    }
}
