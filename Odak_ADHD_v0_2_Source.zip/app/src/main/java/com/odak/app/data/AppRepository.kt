package com.odak.app.data

import android.content.Context
import com.odak.app.model.BrainItem
import com.odak.app.model.Capacity
import com.odak.app.model.FocusTask
import org.json.JSONArray
import org.json.JSONObject

class AppRepository(context: Context) {
    private val sp = context.getSharedPreferences("odak_v02", Context.MODE_PRIVATE)

    fun loadCapacity(): Capacity {
        val raw = sp.getString("capacity", Capacity.OK.name) ?: Capacity.OK.name
        return runCatching { Capacity.valueOf(raw) }.getOrDefault(Capacity.OK)
    }

    fun saveCapacity(value: Capacity) {
        sp.edit().putString("capacity", value.name).apply()
    }

    fun loadTasks(): List<FocusTask> {
        val raw = sp.getString("tasks", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        FocusTask(
                            id = o.optLong("id"),
                            title = o.optString("title"),
                            firstAction = o.optString("firstAction"),
                            estimateMinutes = o.optInt("estimateMinutes", 15),
                            energy = o.optString("energy", "Orta"),
                            done = o.optBoolean("done", false)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveTasks(tasks: List<FocusTask>) {
        val arr = JSONArray()
        tasks.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("firstAction", it.firstAction)
                    .put("estimateMinutes", it.estimateMinutes)
                    .put("energy", it.energy)
                    .put("done", it.done)
            )
        }
        sp.edit().putString("tasks", arr.toString()).apply()
    }

    fun loadBrainItems(): List<BrainItem> {
        val raw = sp.getString("brain", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        BrainItem(
                            id = o.optLong("id"),
                            text = o.optString("text"),
                            bucket = o.optString("bucket", "Gelen Kutusu"),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveBrainItems(items: List<BrainItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("text", it.text)
                    .put("bucket", it.bucket)
                    .put("createdAt", it.createdAt)
            )
        }
        sp.edit().putString("brain", arr.toString()).apply()
    }

    fun setRoutineDoneToday(routineId: String, done: Boolean) {
        val key = "routine_${todayKey()}_$routineId"
        val wasDone = sp.getBoolean(key, false)
        sp.edit().putBoolean(key, done).apply()
        if (done && !wasDone) {
            sp.edit().putInt("routine_total", sp.getInt("routine_total", 0) + 1).apply()
        }
    }

    fun isRoutineDoneToday(routineId: String): Boolean =
        sp.getBoolean("routine_${todayKey()}_$routineId", false)

    fun routineTotal(): Int = sp.getInt("routine_total", 0)

    fun recordFocus(minutes: Int) {
        sp.edit()
            .putInt("focus_minutes", sp.getInt("focus_minutes", 0) + minutes)
            .putInt("focus_sessions", sp.getInt("focus_sessions", 0) + 1)
            .apply()
    }

    fun focusMinutes(): Int = sp.getInt("focus_minutes", 0)
    fun focusSessions(): Int = sp.getInt("focus_sessions", 0)

    fun backendEndpoint(): String = sp.getString("cbt_backend", "") ?: ""
    fun saveBackendEndpoint(value: String) {
        sp.edit().putString("cbt_backend", value.trim()).apply()
    }

    private fun todayKey(): String {
        val c = java.util.Calendar.getInstance()
        return "${c.get(java.util.Calendar.YEAR)}-${c.get(java.util.Calendar.DAY_OF_YEAR)}"
    }
}
