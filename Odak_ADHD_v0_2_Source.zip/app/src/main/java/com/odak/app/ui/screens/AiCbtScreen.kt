package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.odak.app.data.CbtBackendClient
import com.odak.app.model.ChatMessage
import com.odak.app.ui.AppState
import com.odak.app.ui.theme.Cream
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiCbtScreen(
    appState: AppState,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                "assistant",
                "Burada bir düşünceyi birlikte yavaşlatabiliriz. Ne oldu? Kısa yazman yeterli."
            )
        )
    }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Cream,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("CBT Rehberi")
                        Text(
                            if (appState.backendEndpoint.isBlank())
                                "Yapılandırılmış yerel mod"
                            else
                                "AI destekli mod",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, "Geri")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text("Aklından geçen…") },
                        modifier = Modifier.weight(1f),
                        maxLines = 4
                    )
                    FilledIconButton(
                        onClick = {
                            val userText = input.trim()
                            if (userText.isBlank() || loading) return@FilledIconButton

                            input = ""
                            messages.add(ChatMessage("user", userText))

                            if (looksLikeImmediateSafetyRisk(userText)) {
                                messages.add(
                                    ChatMessage(
                                        "assistant",
                                        "Şu anda kendine zarar verme riski veya acil bir tehlike varsa bu sohbeti kriz desteği olarak kullanma. Türkiye'deysen 112'yi ara ya da en yakın acil servise git; mümkünse yanında güvendiğin birini bulundur."
                                    )
                                )
                                return@FilledIconButton
                            }

                            if (appState.backendEndpoint.isBlank()) {
                                messages.add(
                                    ChatMessage(
                                        "assistant",
                                        localCbtReply(messages)
                                    )
                                )
                            } else {
                                loading = true
                                scope.launch {
                                    val result = CbtBackendClient.send(
                                        appState.backendEndpoint,
                                        messages.toList()
                                    )
                                    messages.add(
                                        ChatMessage(
                                            "assistant",
                                            result.getOrElse {
                                                "AI bağlantısına ulaşamadım. İstersen yine yapılandırılmış şekilde ilerleyelim: Bu düşünceyi yüzde 100 doğru yapmayan bir veri var mı? Ardından 5 dakikalık en küçük hareketi seç."
                                            }
                                        )
                                    )
                                    loading = false
                                }
                            }
                        },
                        enabled = input.isNotBlank() && !loading
                    ) {
                        Icon(Icons.Rounded.Send, "Gönder")
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AssistChip(
                    onClick = {},
                    label = {
                        Text("Tanı / ilaç önermez · terapi veya kriz hizmetinin yerini tutmaz")
                    }
                )
            }

            items(messages) { message ->
                val isUser = message.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement =
                        if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color =
                            if (isUser)
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.large,
                        modifier = Modifier.fillMaxWidth(0.86f)
                    ) {
                        Text(
                            message.text,
                            modifier = Modifier.padding(14.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            if (loading) {
                item {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }

            item {
                Text(
                    "Konuşma bu prototipte cihazda kalıcı olarak saklanmaz.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun looksLikeImmediateSafetyRisk(text: String): Boolean {
    val x = text.lowercase()
    val phrases = listOf(
        "kendimi öldür",
        "intihar",
        "kendime zarar",
        "yaşamak istemiyorum",
        "kill myself",
        "suicide"
    )
    return phrases.any { x.contains(it) }
}

private fun localCbtReply(messages: List<ChatMessage>): String {
    val userCount = messages.count { it.role == "user" }
    return when (userCount) {
        1 -> "Bu durumda aklından geçen en sert veya en hızlı cümle neydi? Olduğu gibi yaz."
        2 -> "Bu düşünce sende hangi duyguyu oluşturdu? İstersen 0–10 arası yoğunluğunu da ekle."
        3 -> "Şimdi kanıt tarafına bakalım: Bu düşünceyi destekleyen somut gerçek ne? Peki onu yüzde 100 doğru yapmayan bir veri veya başka bir açıklama var mı?"
        4 -> "Aynı durumda sevdiğin bir arkadaşın olsa ona ne söylerdin? Bunu kendin için daha dengeli tek bir cümleye çevirebilir misin?"
        else -> "Güzel. Şimdi düşünceyi çözmeye devam etmek yerine davranışa bağlayalım: Önümüzdeki 5 dakikada yapabileceğin en küçük fiziksel hareket ne?"
    }
}
