package com.odak.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

val Cream = Color(0xFFFFF9F3)
val SurfaceWarm = Color(0xFFFFFDF9)
val Ink = Color(0xFF26332D)
val Muted = Color(0xFF707B75)
val Sage = Color(0xFF729B80)
val SageDeep = Color(0xFF4F745D)
val SageSoft = Color(0xFFE5EFE7)
val Lavender = Color(0xFFEDE7F7)
val Peach = Color(0xFFF9E6DA)
val Sun = Color(0xFFF8EFC8)
val Sky = Color(0xFFE4EFF5)

private val LightColors = lightColorScheme(
    primary = SageDeep,
    onPrimary = Color.White,
    primaryContainer = SageSoft,
    onPrimaryContainer = Ink,
    secondary = Color(0xFF8D7CB4),
    secondaryContainer = Lavender,
    tertiary = Color(0xFFB27659),
    tertiaryContainer = Peach,
    background = Cream,
    onBackground = Ink,
    surface = SurfaceWarm,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF4F0EA),
    onSurfaceVariant = Muted,
    outline = Color(0xFFD8D2CA)
)

private val OdakShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun OdakTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = Typography(),
        shapes = OdakShapes,
        content = content
    )
}
