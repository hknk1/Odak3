package com.odak.app.data

import com.odak.app.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object CbtBackendClient {
    suspend fun send(endpoint: String, messages: List<ChatMessage>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(endpoint.startsWith("https://")) {
                    "Güvenlik için backend adresi https:// ile başlamalı."
                }

                val url = URL(endpoint.trimEnd('/') + "/cbt")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }

                val arr = JSONArray()
                messages.takeLast(12).forEach { m ->
                    arr.put(JSONObject().put("role", m.role).put("content", m.text))
                }

                val body = JSONObject()
                    .put("mode", "adhd_cbt_support")
                    .put("language", "tr")
                    .put("messages", arr)
                    .toString()

                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }

                if (code !in 200..299) {
                    error("Backend yanıtı: HTTP $code")
                }

                val json = JSONObject(response)
                json.optString("reply").takeIf { it.isNotBlank() }
                    ?: error("Backend 'reply' alanı döndürmedi.")
            }
        }
}
