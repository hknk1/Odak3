# Odak — ADHD günlük yaşam sistemi (v0.2)

Bu sürüm sıfırdan oluşturulan Compose tabanlı ürünün ikinci kodlama turudur.

## v0.2'de eklenenler
- Daha sıcak / premium ana ekran
- Bugünkü kapasite + görev enerji seviyesi
- En fazla 3 görünür odak
- Odak istatistikleri
- Rutin motoru: Normal / Kısa / Minimum
- Günlük rutin ilerlemesi ve toplam rutin sayımı
- Dış Beyin sekmesi
- Brain Dump gelen kutusu
- Bugün / Sonra / Sil ayrıştırması
- Yerel hatırlatıcılar (WorkManager + bildirim)
- Geçiş Asistanı
  - işe başlama
  - moladan dönme
  - evden çıkma
  - işi kapatma
- Geliştirilmiş Odak ekranı
- Body Double hedef görünürlüğü
- Dikkat park alanı
- Geliştirilmiş "Kitlendim" akışı
- Tam ekran CBT sohbet alanı
- Backend ayarlıysa gerçek AI endpoint bağlantısı
- Backend yoksa yerel yapılandırılmış CBT akışı
- Basit kriz / güvenlik yönlendirmesi
- CBT konuşmaları bu prototipte kalıcı olarak saklanmaz

## AI backend sözleşmesi
Mobil uygulama API anahtarı içermez.

`Ben > AI bağlantı ayarları` bölümüne güvenli HTTPS backend adresi girilir.

Uygulama şuraya POST yapar:

`POST {BACKEND_URL}/cbt`

İstek örneği:
```json
{
  "mode": "adhd_cbt_support",
  "language": "tr",
  "messages": [
    {"role":"user","content":"..."}
  ]
}
```

Beklenen yanıt:
```json
{"reply":"..."}
```

Backend tarafında model sağlayıcı anahtarı saklanmalı; mobil APK içine gizli anahtar konmamalıdır.

## Sağlık sınırı
Uygulama tanı veya tedavi sağlamaz; ilaç, doz ve kullanım saati önermez. AI alanı terapi veya kriz hizmeti değildir.

## Bir sonraki teknik tur
- Takvim entegrasyonu
- Belirli tarih/saat hatırlatıcıları
- Gerçek haftalık örüntü analizi
- Özel rutin oluşturucu
- Uyku / hareket modülleri
- Güvenli backend sunucusunun kurulması
