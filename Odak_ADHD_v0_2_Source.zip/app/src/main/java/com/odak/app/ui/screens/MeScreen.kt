package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.odak.app.ui.AppState
import com.odak.app.ui.components.PageHeader
import com.odak.app.ui.components.SectionTitle
import com.odak.app.ui.components.SoftStat
import com.odak.app.ui.components.WarmCard
import com.odak.app.ui.theme.Lavender
import com.odak.app.ui.theme.SageSoft

@Composable
fun MeScreen(
    appState: AppState,
    onOpenCbt: () -> Unit
) {
    var settingsOpen by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PageHeader(
                "Ben",
                "Kendini ölçmek değil, kendini tanımak.",
                "Amaç kusursuz seri değil; işe yarayan sistemi zamanla bulmak."
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SoftStat("${appState.focusSessions()}", "odak", Modifier.weight(1f))
                SoftStat("${appState.focusMinutes()}", "dakika", Modifier.weight(1f))
                SoftStat("${appState.routineTotal()}", "rutin", Modifier.weight(1f))
            }
        }

        item {
            WarmCard(tint = Lavender) {
                SectionTitle(
                    "AI CBT Sohbeti",
                    "Düşünceyi yapılandırıp küçük bir sonraki davranışa bağlamak için."
                )
                Button(onClick = onOpenCbt) {
                    Icon(Icons.Rounded.Chat, null)
                    Spacer(Modifier.width(8.dp))
                    Text("CBT rehberini aç")
                }

                val modeText =
                    if (appState.backendEndpoint.isBlank())
                        "Şu an yapılandırılmış yerel rehber modu açık."
                    else
                        "Güvenli backend bağlantısı ayarlı."

                Text(
                    modeText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                TextButton(onClick = { settingsOpen = true }) {
                    Text("AI bağlantı ayarları")
                }
            }
        }

        item {
            WarmCard(tint = SageSoft) {
                SectionTitle("Haftalık öğrenme")
                Text("• Hangi odak süreleri daha sık tamamlanıyor?")
                Text("• Hangi rutin yoğunluğu gerçek hayatına uyuyor?")
                Text("• Düşük kapasite günlerinde plan ne kadar küçülüyor?")
                Text(
                    "Bu sürüm temel toplamları topluyor. Sonraki analiz katmanı yalnızca kendi verindeki örüntüleri gösterecek; neden-sonuç iddiasında bulunmayacak.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            WarmCard {
                SectionTitle("Sağlık ve tedavi sınırı")
                Text(
                    "Odak, ADHD tedavisinin yerine geçmez. Tanı koymaz; reçete, doz veya ilaç saatinde değişiklik önermez. Kişisel tedavi kararları sağlık profesyoneliyle verilmelidir.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (settingsOpen) {
        BackendSettingsDialog(
            current = appState.backendEndpoint,
            onDismiss = { settingsOpen = false },
            onSave = {
                appState.saveBackendEndpoint(it)
                settingsOpen = false
            }
        )
    }
}

@Composable
private fun BackendSettingsDialog(
    current: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var endpoint by remember(current) { mutableStateOf(current) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI backend adresi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "API anahtarı uygulamaya yazılmaz. Adres, kendi güvenli sunucundaki /cbt endpoint'ine bağlanır."
                )
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    label = { Text("https://…") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Boş bırakırsan uygulama yerel yapılandırılmış CBT rehberini kullanır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(endpoint) }) { Text("Kaydet") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Vazgeç") }
        }
    )
}
