package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RescueDialog(
    onDismiss: () -> Unit,
    onStartFive: () -> Unit,
    onOpenCbt: () -> Unit,
    onOpenBrain: () -> Unit
) {
    var selected by remember { mutableStateOf<String?>(null) }

    val options = listOf(
        "Başlayamıyorum",
        "Çok fazla şey var",
        "Ne yapacağımı bilmiyorum",
        "Dikkatim dağılıyor",
        "Enerjim yok",
        "Kaygı / kendime yüklenme"
    )

    val guidance = when (selected) {
        "Başlayamıyorum" ->
            "Bitirmeyi hedefleme. Gereken ilk nesneyi veya dosyayı önüne getir."
        "Çok fazla şey var" ->
            "Önce kafandakileri dışarı çıkar. Sonra yapılmaması gerçek sorun yaratacak tek şeyi seç."
        "Ne yapacağımı bilmiyorum" ->
            "Sonucu değil ilk fiziksel hareketi tarif et: aç, getir, yaz, ara, giy."
        "Dikkatim dağılıyor" ->
            "Telefonu kol mesafesinin dışına koy. Aklına gelenleri Sonra listesine park et."
        "Enerjim yok" ->
            "Minimum plana geç: temel ihtiyaç + tek zorunlu iş + 5 dakika."
        "Kaygı / kendime yüklenme" ->
            "Burada düşünce engeli olabilir. Kısa CBT akışına geçebilirsin."
        else -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🛟 Kitlendim") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selected == null) {
                    Text("Şu anda hangisine daha yakınsın?")
                    options.forEach { option ->
                        OutlinedButton(
                            onClick = { selected = option },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(option) }
                    }
                } else {
                    Text(selected!!, style = MaterialTheme.typography.titleMedium)
                    Text(guidance.orEmpty(), style = MaterialTheme.typography.bodyLarge)
                    TextButton(onClick = { selected = null }) { Text("Geri") }
                }
            }
        },
        confirmButton = {
            if (selected != null) {
                when (selected) {
                    "Kaygı / kendime yüklenme" ->
                        Button(onClick = onOpenCbt) { Text("CBT rehberine geç") }
                    "Çok fazla şey var" ->
                        Button(onClick = onOpenBrain) { Text("Brain Dump aç") }
                    else ->
                        Button(onClick = onStartFive) { Text("5 dk başla") }
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Kapat") } }
    )
}
