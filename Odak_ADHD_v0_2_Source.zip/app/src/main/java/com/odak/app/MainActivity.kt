package com.odak.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.odak.app.ui.OdakApp
import com.odak.app.ui.theme.OdakTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OdakTheme {
                OdakApp()
            }
        }
    }
}
