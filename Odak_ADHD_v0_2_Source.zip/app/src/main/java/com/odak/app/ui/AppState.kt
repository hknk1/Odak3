package com.odak.app.ui

import android.content.Context
import androidx.compose.runtime.*
import com.odak.app.data.AppRepository
import com.odak.app.model.*

class AppState(context: Context) {
    private val repo = AppRepository(context)

    var capacity by mutableStateOf(repo.loadCapacity())
        private set

    val tasks = mutableStateListOf<FocusTask>().apply { addAll(repo.loadTasks()) }
    val brainItems = mutableStateListOf<BrainItem>().apply { addAll(repo.loadBrainItems()) }

    var statsVersion by mutableIntStateOf(0)
        private set

    var backendEndpoint by mutableStateOf(repo.backendEndpoint())
        private set

    fun setCapacity(value: Capacity) {
        capacity = value
        repo.saveCapacity(value)
    }

    fun addTask(
        title: String,
        firstAction: String,
        estimateMinutes: Int,
        energy: String
    ) {
        if (title.isBlank()) return
        tasks.add(
            FocusTask(
                title = title.trim(),
                firstAction = firstAction.trim(),
                estimateMinutes = estimateMinutes.coerceIn(5, 240),
                energy = energy
            )
        )
        persistTasks()
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i >= 0) {
            tasks[i] = tasks[i].copy(done = !tasks[i].done)
            persistTasks()
        }
    }

    fun addBrainItem(text: String, bucket: String = "Gelen Kutusu") {
        if (text.isBlank()) return
        brainItems.add(BrainItem(text = text.trim(), bucket = bucket))
        repo.saveBrainItems(brainItems)
    }

    fun moveBrainItem(id: Long, bucket: String) {
        val i = brainItems.indexOfFirst { it.id == id }
        if (i >= 0) {
            if (bucket == "Sil") brainItems.removeAt(i)
            else brainItems[i] = brainItems[i].copy(bucket = bucket)
            repo.saveBrainItems(brainItems)
        }
    }

    fun routineDone(id: String): Boolean {
        statsVersion
        return repo.isRoutineDoneToday(id)
    }

    fun setRoutineDone(id: String, done: Boolean) {
        repo.setRoutineDoneToday(id, done)
        statsVersion++
    }

    fun completedRoutineCountToday(): Int {
        statsVersion
        return routines.count { repo.isRoutineDoneToday(it.id) }
    }

    fun recordFocus(minutes: Int) {
        repo.recordFocus(minutes)
        statsVersion++
    }

    fun focusMinutes(): Int {
        statsVersion
        return repo.focusMinutes()
    }

    fun focusSessions(): Int {
        statsVersion
        return repo.focusSessions()
    }

    fun routineTotal(): Int {
        statsVersion
        return repo.routineTotal()
    }

    fun saveBackendEndpoint(value: String) {
        repo.saveBackendEndpoint(value)
        backendEndpoint = value.trim()
    }

    private fun persistTasks() = repo.saveTasks(tasks)
}

val routines = listOf(
    RoutineTemplate(
        id = "morning",
        title = "Sabah Başlat",
        emoji = "☀️",
        subtitle = "Günü düşünerek değil, küçük bir akışla başlat.",
        normal = listOf(
            "Perdeyi aç / ışığı içeri al",
            "Su, kahvaltı ve temel kişisel bakım",
            "Bugünkü kapasiteni seç",
            "Bugün yeterli olacak 3 şeyi seç",
            "İlk görevin ilk fiziksel hareketini hazırla",
            "5 dakika başla"
        ),
        short = listOf(
            "Su ve temel kişisel bakım",
            "Bugünün tek önemli işini seç",
            "İlk fiziksel hareketi hazırla",
            "5 dakika başla"
        ),
        minimum = listOf(
            "Temel ihtiyacını karşıla",
            "Tek zorunlu işi seç",
            "Sadece 5 dakika başla"
        )
    ),
    RoutineTemplate(
        id = "work",
        title = "İşe / Çalışmaya Başla",
        emoji = "🧩",
        subtitle = "Çevreyi hazırla, tek işi seç, başlama bariyerini küçült.",
        normal = listOf(
            "Masadaki gereksiz şeyleri kenara al",
            "Telefonu kol mesafesinin dışına koy",
            "Tek görevi seç",
            "İlk fiziksel hareketi aç",
            "Süre tahmini yap",
            "15–25 dakika odak başlat"
        ),
        short = listOf(
            "Telefonu park et",
            "Tek işi seç",
            "İlk hareketi aç",
            "15 dakika başla"
        ),
        minimum = listOf(
            "Tek işi seç",
            "Gereken dosya / nesneyi aç",
            "5 dakika başla"
        )
    ),
    RoutineTemplate(
        id = "midday",
        title = "Öğlen Reset",
        emoji = "🌿",
        subtitle = "Planı gerçek enerjiye göre yeniden ayarla.",
        normal = listOf(
            "Şu an ne yaptığını fark et",
            "Bugünün en önemli işi hâlâ aynı mı?",
            "Enerjini yeniden değerlendir",
            "Gereksiz bir işi Sonra listesine taşı",
            "Gerekirse kısa hareket / su molası",
            "Bir sonraki küçük adımı seç"
        ),
        short = listOf(
            "Enerjini kontrol et",
            "Tek önceliği yeniden seç",
            "Bir sonraki küçük adımı yap"
        ),
        minimum = listOf(
            "Planı küçült",
            "Tek işi seç",
            "5 dakika devam et"
        )
    ),
    RoutineTemplate(
        id = "evening",
        title = "Akşam Kapat",
        emoji = "🌙",
        subtitle = "Açık döngüleri kafanda tutmadan günü kapat.",
        normal = listOf(
            "Aklında kalanları Brain Dump'a bırak",
            "Bitmeyen işleri Yarın / Sonra olarak ayır",
            "Yarının 1 numaralı işini seç",
            "İlk hareket için gereken şeyi hazırla",
            "Yarınki randevu / zorunluluklara bak",
            "Ekranı ve işi kapat"
        ),
        short = listOf(
            "Açık işleri dışarı çıkar",
            "Yarının tek önemli işini seç",
            "İlk hareketi hazırla"
        ),
        minimum = listOf(
            "Yarının tek işini seç",
            "Gereken şeyi görünür bir yere koy"
        )
    )
)

val transitions = listOf(
    TransitionPreset(
        id = "start_work",
        title = "İşe başlıyorum",
        emoji = "▶️",
        subtitle = "Başlangıç sürtünmesini azalt.",
        steps = listOf(
            "Şu anki işi / düşünceyi bir cümleyle park et",
            "Telefonu ve dikkat dağıtıcıları uzaklaştır",
            "Tek görevi seç",
            "İlk fiziksel hareketi aç",
            "5–15 dakikalık başlangıç başlat"
        )
    ),
    TransitionPreset(
        id = "back_break",
        title = "Moladan dönüyorum",
        emoji = "↩️",
        subtitle = "Nerede kaldığını yeniden bul.",
        steps = listOf(
            "Önceki işin adını söyle",
            "Son yaptığın küçük adımı hatırla",
            "Bir sonraki fiziksel hareketi seç",
            "Sadece 5 dakika geri dön"
        )
    ),
    TransitionPreset(
        id = "leave_home",
        title = "Evden çıkıyorum",
        emoji = "🚪",
        subtitle = "Çıkış anındaki unutmayı azalt.",
        steps = listOf(
            "Telefon",
            "Anahtar",
            "Cüzdan / kart",
            "Bugün özel olarak gereken eşya",
            "Kapıyı ve zamanı kontrol et"
        )
    ),
    TransitionPreset(
        id = "close_work",
        title = "İşi kapatıyorum",
        emoji = "🌆",
        subtitle = "Açık döngüleri kafanda eve taşıma.",
        steps = listOf(
            "Nerede kaldığını bir cümleyle yaz",
            "Aklında kalanları Dış Beyin'e bırak",
            "Yarının ilk fiziksel hareketini seç",
            "Çalışma alanını kapat",
            "Bitti sinyalini ver: kalk / ışığı değiştir / kısa yürüyüş"
        )
    )
)
