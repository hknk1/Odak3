package com.odak.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.odak.app.model.Capacity
import com.odak.app.ui.AppState
import com.odak.app.ui.components.*
import com.odak.app.ui.theme.*
import java.util.Calendar

@Composable
fun TodayScreen(
    appState: AppState,
    onStartFocus: () -> Unit,
    onOpenBrain: () -> Unit,
    onOpenCbt: () -> Unit
) {
    var addTaskOpen by remember { mutableStateOf(false) }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when (hour) {
        in 5..11 -> "Günaydın"
        in 12..17 -> "Merhaba"
        else -> "İyi akşamlar"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PageHeader(
                kicker = "Bugün",
                title = "$greeting 🌿",
                subtitle = "Planı ideal gününe değil, bugünkü gerçek kapasitenle eşleştir."
            )
        }

        item {
            WarmCard(tint = SageSoft) {
                Text("Bugünkü kapasiten", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Capacity.entries.forEach { c ->
                        FilterChip(
                            selected = appState.capacity == c,
                            onClick = { appState.setCapacity(c) },
                            label = { Text(c.emoji) }
                        )
                    }
                }
                Text(
                    "${appState.capacity.emoji} ${appState.capacity.label}",
                    style = MaterialTheme.typography.titleLarge
                )
                if (appState.capacity == Capacity.VERY_LOW || appState.capacity == Capacity.LOW) {
                    Text(
                        "Bugün hedefi küçültmek planın bozulması değil; planın sana uyum sağlaması.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SoftStat(
                    "${appState.tasks.count { it.done }}",
                    "tamamlandı",
                    Modifier.weight(1f)
                )
                SoftStat(
                    "${appState.completedRoutineCountToday()}/4",
                    "rutin",
                    Modifier.weight(1f)
                )
                SoftStat(
                    "${appState.focusMinutes()}",
                    "odak dk",
                    Modifier.weight(1f)
                )
            }
        }

        item {
            WarmCard {
                SectionTitle(
                    "Bugün yeterli olacak 3 şey",
                    "En fazla üç görünür odak. Geri kalanı dışarıda tut."
                )

                val visible = appState.tasks.filter { !it.done }.take(3)
                if (visible.isEmpty()) {
                    Text(
                        "Henüz odak seçmedin. Bugün sonuç yaratacak en küçük şeyi ekle.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    visible.forEach { task ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when (task.energy) {
                                    "Düşük" -> Sun
                                    "Yüksek" -> Peach
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(task.title, style = MaterialTheme.typography.titleMedium)
                                if (task.firstAction.isNotBlank()) {
                                    Text(
                                        "İlk hareket → ${task.firstAction}",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${task.estimateMinutes} dk") }
                                    )
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${task.energy} enerji") }
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = onStartFocus) {
                                        Icon(Icons.Rounded.PlayArrow, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Başla")
                                    }
                                    TextButton(onClick = { appState.toggleTask(task.id) }) {
                                        Text("Tamamlandı")
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = { addTaskOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Odak ekle")
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickAction(
                    modifier = Modifier.weight(1f),
                    emoji = "🧠",
                    title = "Dış Beyin",
                    subtitle = "Aklından çıkar",
                    onClick = onOpenBrain
                )
                QuickAction(
                    modifier = Modifier.weight(1f),
                    emoji = "💬",
                    title = "CBT",
                    subtitle = "Düşünceyi çöz",
                    onClick = onOpenCbt
                )
            }
        }

        item {
            WarmCard(tint = Peach) {
                SectionTitle("Nazik gün", "Kapasite düştüğünde plan da küçülür.")
                Text("Temel ihtiyaç → tek zorunlu iş → 5 dakikalık başlangıç.")
                Button(onClick = onStartFocus) {
                    Text("5 dakikalık minimum başlangıç")
                }
            }
        }
    }

    if (addTaskOpen) {
        AddTaskDialog(
            onDismiss = { addTaskOpen = false },
            onSave = { title, first, minutes, energy ->
                appState.addTask(title, first, minutes, energy)
                addTaskOpen = false
            }
        )
    }
}

@Composable
private fun QuickAction(
    modifier: Modifier,
    emoji: String,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(emoji, style = MaterialTheme.typography.headlineMedium)
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Int, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var estimate by remember { mutableStateOf("15") }
    var energy by remember { mutableStateOf("Orta") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni odak") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Sonuç ne?") },
                    placeholder = { Text("Örn. sunumun girişini hazırla") }
                )
                OutlinedTextField(
                    value = first,
                    onValueChange = { first = it },
                    label = { Text("İlk fiziksel hareket") },
                    placeholder = { Text("Örn. sunum dosyasını aç") }
                )
                OutlinedTextField(
                    value = estimate,
                    onValueChange = { estimate = it.filter(Char::isDigit).take(3) },
                    label = { Text("Tahmini dakika") }
                )
                Text("Gereken enerji", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Düşük", "Orta", "Yüksek").forEach { e ->
                        FilterChip(
                            selected = energy == e,
                            onClick = { energy = e },
                            label = { Text(e) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(title, first, estimate.toIntOrNull() ?: 15, energy)
                },
                enabled = title.isNotBlank()
            ) { Text("Ekle") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}
